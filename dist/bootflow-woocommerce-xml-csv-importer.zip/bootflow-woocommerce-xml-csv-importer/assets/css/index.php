<?php
// Silence is golden
if (!defined('ABSPATH')) {
    exit;
}
